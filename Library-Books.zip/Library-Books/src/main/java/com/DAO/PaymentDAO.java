package com.DAO;

import entity.Payment_Details;

public interface PaymentDAO {
	
	
	public boolean paymentDetails(Payment_Details p);
}
