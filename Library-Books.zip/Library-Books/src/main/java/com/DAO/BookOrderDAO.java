package com.DAO;

import java.util.List;

import entity.Book_Order;
import entity.Payment_Details;

public interface BookOrderDAO {

	public int getOrderNo();
	
	public boolean saveOrder(List<Book_Order> b);
	
	public List<Book_Order> getBook(String email);
	
	public List<Book_Order> getAllOrder();
	
}
