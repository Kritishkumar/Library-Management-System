package entity;

public class Payment_Details {

	private int id;
	private String card;
	private String exp;
	private String cvv;
	private String amt;
	private String option;
	private String upino;
	
	
	public Payment_Details() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getCard() {
		return card;
	}


	public void setCard(String card) {
		this.card = card;
	}


	public String getExp() {
		return exp;
	}


	public void setExp(String exp) {
		this.exp = exp;
	}


	public String getCvv() {
		return cvv;
	}


	public void setCvv(String cvv) {
		this.cvv = cvv;
	}


	public String getAmt() {
		return amt;
	}


	public void setAmt(String amt) {
		this.amt = amt;
	}


	public String getOption() {
		return option;
	}


	public void setOption(String option) {
		this.option = option;
	}


	public String getUpino() {
		return upino;
	}


	public void setUpino(String upino) {
		this.upino = upino;
	}


	@Override
	public String toString() {
		return "Payment_Details [id=" + id + ", card=" + card + ", exp=" + exp + ", cvv=" + cvv + ", amt=" + amt
				+ ", option=" + option + ", upino=" + upino + "]";
	}


	
	
	
}
