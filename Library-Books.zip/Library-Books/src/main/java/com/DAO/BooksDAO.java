package com.DAO;


import java.util.List;



import entity.BookDetails;

public interface BooksDAO {

	public boolean addBooks(BookDetails b);
	
	public List<BookDetails> getAllBooks();
	
	public BookDetails geBookById(int id );
	
	public boolean updateEditBooks(BookDetails b);
	
	public boolean deleteBooks(int id);
	
	public List<BookDetails> getNewBook(); 
	
	public List<BookDetails> getRecentBook();
	
	public List<BookDetails> getOldBooks();
	
	public List<BookDetails> getAllRecentBook();
	
	public List<BookDetails> getAllNewBook();
	
	public List<BookDetails> getAllOldBook();
	
	public List<BookDetails> getBookByOld(String email,String cate);
	
	public boolean oldBookDelete(String email,String cat,int id);
	
	public List<BookDetails> getBookBySearch(String ch);
	
	
	
	
	
	
}
