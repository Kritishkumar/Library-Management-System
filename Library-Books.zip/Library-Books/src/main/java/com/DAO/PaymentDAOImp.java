package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import entity.Payment_Details;

public class PaymentDAOImp implements PaymentDAO {

	private Connection conn;
	
	
	public PaymentDAOImp(Connection conn) {
		super();
		this.conn = conn;
	}




	@Override
	public boolean paymentDetails(Payment_Details p) {
		boolean f=false;
		
		try {
			String sql="insert into payment_details(cardno,expirydate,cvvno,amt) values(?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sql);
			
			ps.setString(1, p.getCard());
			ps.setString(2,p.getExp());
			ps.setString(3, p.getCvv());
			ps.setString(4,p.getAmt());
//			ps.setString(5, p.getOption());
//			ps.setString(6, p.getUpino());
			
			int i=ps.executeUpdate();
			if(i==1)
			{
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	
	
}
