package com.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.PaymentDAOImp;
import com.DB.DBConnect;

import entity.Payment_Details;


@WebServlet("/payment_details")
public class PaymentServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		try {
			
			String card=req.getParameter("card");
			String exp=req.getParameter("exp");
			String cvv=req.getParameter("cvv");
			String amt=req.getParameter("amt");
//			String option=req.getParameter("option");
//			String upino=req.getParameter("upino");
			
			
			System.out.println(card+" "+exp+" "+cvv+" "+amt);
			
			Payment_Details pd=new Payment_Details();
			
			pd.setCard(card);
			pd.setExp(exp);
			pd.setCvv(cvv);
			pd.setAmt(amt);
//			pd.setOption(option);
//			pd.setUpino(upino);
			
			PaymentDAOImp dao=new PaymentDAOImp(DBConnect.getConn());
			
			boolean f=dao.paymentDetails(pd);
			
			if(f)
			{
				System.out.println("payment Success");
			}
			else
			{
				System.out.println("Something went wrong");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
	
	
}
